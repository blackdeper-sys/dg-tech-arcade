# DG TECH ARCADE — Como Funcionar com o Computador Desligado (24h Online)

Este guia explica exatamente **por que o painel parou quando você desligou o computador** e **como fazer tudo funcionar 24h por dia sem depender de PC ligado**.

---

## 🔍 1. Por que parou de abrir quando desligou o computador?

Atualmente, o painel do celular e o link de acesso remoto (`trycloudflare.com`) estavam rodando **dentro do seu computador Windows** através do arquivo `server.py` e do programa `cloudflared.exe`.

- Ao desligar o computador:
  1. O programa `server.py` desligou.
  2. O túnel da Cloudflare caiu.
  3. O link que você abriu no celular parou de responder (*"Não foi possível acessar este site"*).
- Ao religar o computador:
  - O servidor não inicia sozinho a menos que você clique no arquivo `INICIAR_ACESSO_REMOTO_4G.bat`.

---

## 🕹️ 2. A Máquina de Fliperama na Barbearia (ESP32 + Relé)

> **BOA NOTÍCIA:** A máquina de fliperama **NÃO PRECISA DO COMPUTADOR** para os clientes jogarem!

O código que está dentro do ESP32 (CYD com tela touch) e do módulo Relé (ESP-01S) é 100% autônomo:
- Ele conecta diretamente no Wi-Fi da Barbearia.
- Gera o QR Code Pix com sua chave do Mercado Pago.
- Verifica sozinho na nuvem se o cliente pagou.
- Aciona o relé da ficha no fliperama automaticamente.

### 🔌 O que é necessário na Barbearia?
1. **Fonte na tomada (5V 2A)**: Ligue o ESP32 e o Relé em uma fonte/carregador de celular comum (ou fonte da própria máquina) direto na tomada. **Não deixe ligado na porta USB do computador**.
2. **Wi-Fi ativo**: A máquina precisa estar no alcance da rede Wi-Fi configurada.

Com isso, clientes podem comprar fichas a qualquer hora do dia ou da noite, com seu computador totalmente desligado!

---

## 📱 3. O Painel de Controle e Vendas no Celular (Sem Computador)

Para você acompanhar o faturamento, ver as vendas Pix, conferir os 50% da barbearia e controlar o sistema pelo celular **com o computador desligado**, o servidor web precisa ser colocado na **Nuvem Gratuita**.

### 🌟 Opção Recomendada: Hospedagem Gratuita no Render.com (24h/7d)

Já deixamos todos os arquivos de configuração prontos nesta pasta (`Procfile`, `requirements.txt`, `render.yaml`).

#### Passo a Passo Detalhado (Em 3 Minutos):

Como o Render precisa de um repositório para puxar seu servidor:

##### Passo 1: Criar o Repositório no GitHub (100% Gratuito)
1. Se ainda não tiver conta, entre em [github.com](https://github.com) e crie uma conta gratuita (ou faça login com o mesmo e-mail do Google).
2. No canto superior direito, clique no botão verde **"New"** (ou no **+** > **New repository**).
3. Em **Repository name**, digite: `dg-tech-arcade`.
4. Pode deixar como **Public** e clique no botão verde **"Create repository"** no final da página.
5. Na página que abrir, clique no link azul **"uploading an existing file"** (enviar arquivos existentes).
6. Arraste para a tela os arquivos principais desta pasta:
   - `server.py`
   - `index.html`
   - `style.css`
   - `app.js`
   - `dados_vendas.json`
   - `requirements.txt`
   - `Procfile`
   - `render.yaml`
   *(Não precisa arrastar o `cloudflared.exe` que é pesado e só serve para Windows)*.
7. No final da página do GitHub, clique no botão verde **"Commit changes"**.

##### Passo 2: Conectar no Render
1. No painel do [Render Dashboard](https://dashboard.render.com), clique no botão azul **New +** no canto superior direito e escolha **Web Service**.
2. Escolha a opção **Build and deploy from a Git repository** e clique em **Next**.
3. Em **Connect a repository**, conecte sua conta do GitHub e selecione o repositório `dg-tech-arcade` que você acabou de criar.
4. O Render vai ler as configurações automaticamente:
   - **Name:** `dg-tech-arcade`
   - **Runtime:** `Python 3`
   - **Build Command:** (deixe vazio)
   - **Start Command:** `python server.py`
   - **Instance Type:** selecione **Free** ($0/month)
5. Clique no botão azul **"Deploy Web Service"** (ou **Create Web Service**).

##### Passo 3: Pegar o Link do Celular
- O Render vai iniciar o servidor em cerca de 1 a 2 minutos. Quando ficar com a bolinha verde (**Live**), o seu link permanente estará logo no topo da página, no formato:
  👉 `https://dg-tech-arcade-xxxx.onrender.com`
- Abra esse link no celular e adicione à tela inicial! Pronto: seu fliperama e painel de vendas estão 24 horas no ar sem precisar de computador!

#### Vantagens do Servidor na Nuvem:
- ✅ **100% Grátis** e online 24 horas por dia.
- ✅ **Computador desligado**: seu PC pode ficar desligado o mês inteiro.
- ✅ **Link Fixo**: nunca mais muda (o link temporário do trycloudflare mudava toda vez).
- ✅ **Sincronização Contínua**: puxa as vendas do Mercado Pago da barbearia a cada 10 segundos automaticamente.

---

## ⚡ 4. Quer Usar no Computador Agora Enquanto Isso?

Se você está com o computador ligado e quer reabrir o sistema imediatamente:

1. Dê dois cliques em:
   👉 **`INICIAR_ACESSO_REMOTO_4G.bat`**
2. Uma janela preta vai abrir mostrando:
   - O servidor local ativo na porta `8088`.
   - O novo link HTTPS seguro do Cloudflare.
3. Dê dois cliques em **`ABRIR_QR_CODE.bat`** e aponte a câmera do seu celular para a tela para abrir o painel na hora!
